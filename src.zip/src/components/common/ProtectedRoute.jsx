﻿import { Navigate, useLocation } from "react-router-dom";
import useAuthStore from "../../store/authStore";

export default function ProtectedRoute({ children }) {
  const location = useLocation();
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

  if (isAuthenticated) {
    return children;
  }

  return <Navigate to="/login" replace state={{ from: location.pathname }} />;
}
