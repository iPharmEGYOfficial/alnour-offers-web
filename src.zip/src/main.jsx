﻿import ReactDOM from "react-dom/client";
import "leaflet/dist/leaflet.css";
import "./index.css";
import App from "./App";

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
